// video test app

#include "ofApp.h"

// temp
#include "CaptureFrameGrabber/cdebug.h"

// TODO list:
// 1. swizzle in Controller::_GrabFrameAsync should be done on GPU
// 2. there are too many copies made of the framebuffer for each frame 
//  (see pixels in ofWinrtVideoGrabber::initGrabber, and videoTexture in ofApp::setup
// 3. need to throw on errors in Controller class
// 4. need to enumerate devices (GetDevicesAsync code written in Cinder, just import it)


//--------------------------------------------------------------
void ofApp::setup(){

    // camWidth = 320;     camHeight = 240;
    camWidth = 640;     camHeight = 480;

    // worst latency at this size on Surface 2
    // camWidth = 1280;     camHeight = 720;

    // better performance, but grainy image
    // camWidth = 1920;     camHeight = 1080;

    // TODO: device enumeration
#if 0
    // we can now get back a list of devices. 
    vector<ofVideoDevice> devices = vidGrabber.listDevices();

    for (int i = 0; i < devices.size(); i++)
    {
        cout << devices[i].id << ": " << devices[i].deviceName;
        if (devices[i].bAvailable) {
            cout << endl;
        }
        else 
        {
            cout << " - unavailable " << endl;
        }
    }
#endif

    // device id 1 is the camera facing user on Surface 2
    // otherwise use device id 0
    vidGrabber.setDeviceID(0);
    vidGrabber.setDesiredFrameRate(60);
    vidGrabber.initGrabber(camWidth, camHeight);

    // videoInverted = new unsigned char[camWidth*camHeight * bytesPerPixel];

    // nb. bytesPerPixel and videoTexture.loadData() must match
    videoTexture.allocate(camWidth, camHeight, GL_RGB);
    // videoTexture.allocate(camWidth, camHeight, GL_RGBA);
    // videoTexture.allocate(camWidth, camHeight, GL_BGRA_EXT);

    ofSetVerticalSync(true);
}

//--------------------------------------------------------------
void ofApp::update(){

    ofBackground(100, 100, 100);

    vidGrabber.update();

    if (vidGrabber.isFrameNew())
    {
        // TCC("new frame"); TCNL;
        // int totalPixels = camWidth * camHeight * bytesPerPixel;
        unsigned char * pixels = vidGrabber.getPixels();
        //for (int i = 0; i < totalPixels; i++){
        //    videoInverted[i] = 255 - pixels[i];
        //}

        // nb. this probably does an image copy
        //
        videoTexture.loadData(videoInverted, camWidth, camHeight, GL_RGBA);
        // videoTexture.loadData(pixels, camWidth, camHeight, GL_BGRA_EXT);
        // videoTexture.loadData(pixels, camWidth, camHeight, GL_RGB);
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetHexColor(0xffffff);
//    vidGrabber.draw(20, 20);
//    videoTexture.draw(20 + camWidth, 20, camWidth, camHeight);
    vidGrabber.draw(0, 0);
///        videoTexture.draw( camWidth, 0, camWidth, camHeight);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
